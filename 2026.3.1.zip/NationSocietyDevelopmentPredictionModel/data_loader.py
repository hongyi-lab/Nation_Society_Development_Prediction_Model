
"""data_loader.py
Reusable loader for multi‑country, multi‑indicator time‑series data
===============================================================

Key design goals
----------------
* **Single interface** for CSV/Excel *and* live API endpoints (World Bank, OECD…)
* **Pandas DataFrames** as primary containers → easy downstream joins/plots
* **Country‑centric dictionary** output: ``{ISO2/3: DataFrame}`` ready for ``risk_score()``
* **Small cache** layer to avoid excessive API calls in interactive sessions
* Minimal deps: `pandas`, `requests`, `openpyxl` (Excel reader)

Example
-------
>>> from data_loader import DataLoader, WB_INDICATORS
>>> dl = DataLoader()
>>> df_gini = dl.fetch_world_bank(['USA', 'CHN'], WB_INDICATORS['AW'])
>>> df_unrest = dl.load_csv('social_unrest.csv', indicator_name='AS')
>>> merged = dl.merge_indicators([df_gini, df_unrest])
>>> country_dict = dl.to_country_dict(merged)
>>> country_dict['USA'].head()

Author: Hongyi, 2025‑06‑17
"""

from __future__ import annotations
import requests
import pandas as pd
from typing import List, Dict, Optional
from functools import reduce
from io import BytesIO

# --------------------------------------------------------------------------
# Indicator mapping (customisable)
# --------------------------------------------------------------------------
WB_INDICATORS = {
    # Wealth dispersion / inequality —— Gini index (World Bank)
    'AW': 'SI.POV.GINI',
    # Cultural cohesion proxy —— Average years of schooling (Barro‑Lee)
    'AC': 'BAR.RO.CHS',
    # Social tension proxy —— Violent conflict deaths per 100k (World Bank)
    'AS': 'VC.IHR.PSRC.P5',
    # Narrative bandwidth proxy —— Press freedom index (RSF, scraped/local)
    # Not available in WB; leave as placeholder for CSV/Excel ingestion
    'B': None,
    # Cross‑jurisdiction friction —— Net inflow of FDI (% of GDP, WB)
    'μk': 'BX.KLT.DINV.WD.GD.ZS',
    # Skill dispersion —— STEM graduates per 100k (UNESCO)
    'σSkill': 'UIS.STEM.GRAD.P5',
}

OECD_BASE = "https://stats.oecd.org/sdmx-json/data"


class DataLoader:
    """Factory for pulling & harmonising heterogeneous data sources."""

    WB_URL_TPL = (
        "https://api.worldbank.org/v2/country/{country}/indicator/{indicator}"
        "?format=json&per_page=20000"
    )

    def __init__(self, cache: bool = True):
        self.enable_cache = cache
        self._cache: Dict[str, pd.DataFrame] = {}

    # ------------------------------------------------------------------
    # World Bank
    # ------------------------------------------------------------------
    def fetch_world_bank(
        self,
        countries: List[str],
        indicator: str,
        start: Optional[int] = None,
        end: Optional[int] = None,
    ) -> pd.DataFrame:
        """Pull a World Bank indicator for one or more countries."""
        if indicator is None:
            raise ValueError("Indicator cannot be None for WB fetch.")
        frames: List[pd.DataFrame] = []
        for iso in countries:
            cache_key = f"WB::{iso}::{indicator}"
            if self.enable_cache and cache_key in self._cache:
                frames.append(self._cache[cache_key])
                continue

            url = self.WB_URL_TPL.format(country=iso, indicator=indicator)
            if start or end:
                s = start if start else ""
                e = end if end else ""
                url += f"&date={s}:{e}"
            resp = requests.get(url, timeout=20)
            resp.raise_for_status()
            payload = resp.json()
            if len(payload) < 2:  # sometimes WB returns only metadata
                continue
            data = payload[1]
            rows = [
                {
                    "country": d["country"]["id"],
                    "year": int(d["date"]),
                    indicator: float(d["value"]) if d["value"] is not None else pd.NA,
                }
                for d in data
            ]
            df = pd.DataFrame(rows).dropna(subset=[indicator])
            if self.enable_cache:
                self._cache[cache_key] = df
            frames.append(df)

        if not frames:
            raise RuntimeError("No data downloaded from World Bank.")
        return pd.concat(frames, ignore_index=True)

    # ------------------------------------------------------------------
    # OECD (example for STEM skill gap etc.)
    # ------------------------------------------------------------------
    def fetch_oecd(
        self,
        dataset: str,
        query: str,
        value_col: str = "value",
        country_slice: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """Generic OECD SDMX‑JSON pull.
        *dataset* something like "EDU_DEMOGRAPHICS"
        *query*   SDMX dimensions separated by "." e.g. "A.BQ.POPLEXP.T".
        """
        url = f"{OECD_BASE}/{dataset}/{query}?contentType=csv"
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        df = pd.read_csv(BytesIO(resp.content))
        if country_slice:
            df = df[df['LOCATION'].isin(country_slice)]
        df = df.rename(columns={
            'LOCATION': 'country',
            'TIME': 'year',
            'Value': value_col,
        })
        return df[['country', 'year', value_col]]

    # ------------------------------------------------------------------
    # Local files
    # ------------------------------------------------------------------
    @staticmethod
    def load_csv(
        path: str,
        country_col: str = "country",
        year_col: str = "year",
        value_col: str = "value",
        indicator_name: str = "indicator",
        **read_csv_kwargs,
    ) -> pd.DataFrame:
        df = pd.read_csv(path, **read_csv_kwargs)
        df = df.rename(
            columns={country_col: "country", year_col: "year", value_col: indicator_name}
        )
        return df[["country", "year", indicator_name]]

    @staticmethod
    def load_excel(
        path: str,
        sheet_name: int | str = 0,
        country_col: str = "country",
        year_col: str = "year",
        value_col: str = "value",
        indicator_name: str = "indicator",
        **read_xl_kwargs,
    ) -> pd.DataFrame:
        df = pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl", **read_xl_kwargs)
        df = df.rename(
            columns={country_col: "country", year_col: "year", value_col: indicator_name}
        )
        return df[["country", "year", indicator_name]]

    # ------------------------------------------------------------------
    # Utils
    # ------------------------------------------------------------------
    @staticmethod
    def merge_indicators(frames: List[pd.DataFrame]) -> pd.DataFrame:
        """Outer‑join on (country, year) for multiple indicator frames."""
        if not frames:
            raise ValueError("merge_indicators needs at least one DataFrame.")
        return reduce(
            lambda left, right: pd.merge(left, right, on=["country", "year"], how="outer"),
            frames,
        ).sort_values(["country", "year"])

    @staticmethod
    def to_country_dict(df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """Convert master DataFrame to {country: df_without_country_col}."""
        result = {}
        for iso, grp in df.groupby("country"):
            result[iso] = grp.drop(columns="country").set_index("year").sort_index()
        return result

    # ------------------------------------------------------------------
    # Simple cache control
    # ------------------------------------------------------------------
    def clear_cache(self) -> None:
        self._cache.clear()
