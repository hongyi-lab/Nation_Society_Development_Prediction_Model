"""
sd_visualize.py — 简洁可复现的图（matplotlib-only）
规则：
  * 只用 matplotlib；
  * 每个图一个 Figure；
  * 不设颜色/样式（除非用户特别指定）。
"""
from __future__ import annotations
import os
import matplotlib.pyplot as plt
import pandas as pd

def plot_series(y: pd.Series, title: str, ylabel: str, out_path: str) -> None:
    fig = plt.figure()
    ax = fig.add_subplot(111)
    y.plot(ax=ax)
    ax.set_title(title)
    ax.set_xlabel("Year")
    ax.set_ylabel(ylabel)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)

def plot_bar_latest(values: pd.Series, title: str, ylabel: str, out_path: str) -> None:
    fig = plt.figure()
    ax = fig.add_subplot(111)
    values.plot(kind="bar", ax=ax)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)
