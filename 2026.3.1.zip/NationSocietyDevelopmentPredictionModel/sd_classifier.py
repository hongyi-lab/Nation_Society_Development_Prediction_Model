"""
sd_classifier.py — ML pipeline for political instability prediction
--------------------------------------------------------------------
Trains and evaluates three models:
  1. XGBoost (main StateDynamics model) — 14 features from sd_model.py
  2. Random Forest (literature benchmark — Muchlinski et al.)
  3. Logistic Regression on 3-variable PITF baseline (Goldstone et al. 2010)

Design decisions:
  - class_weight='balanced' / scale_pos_weight instead of SMOTE.
    Rationale: van den Goorbergh et al. (JAMIA 2022) shows SMOTE degrades
    probability calibration for rare events without improving discrimination.
    Balanced weights achieve comparable sensitivity while preserving valid
    probability estimates needed for country-level risk scoring.

  - GroupKFold(n_splits=5) by country, not random folds.
    Rationale: country-years from the same country are temporally autocorrelated.
    Randomly splitting creates data leakage — the model memorizes country
    baseline rather than learning generalizable signals. GroupKFold ensures
    each fold tests on countries entirely absent from training.
    Reference: Hegre & Sambanis (2006), sensitivity analysis of civil war onset.

  - Primary metric: AUPRC (Area Under Precision-Recall Curve).
    Rationale: AUC-ROC is dominated by true negatives when classes are severely
    imbalanced (~1:50 in PITF data). AUPRC focuses on the minority class and
    better reflects real-world utility (catching actual instability events).
    Reference: Davis & Goadrich (2006), ICML.

Usage:
    from sd_classifier import build_feature_matrix, train_evaluate, shap_analysis
"""
from __future__ import annotations

import os
import warnings
from typing import Dict, Optional

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.metrics import (
    average_precision_score,
    roc_auc_score,
    f1_score,
)
from xgboost import XGBClassifier
import shap

from sd_model import SixFactorOutputs

# ------------------------------------------------------------------
# Feature schema (must match sd_model.SixFactorOutputs fields)
# ------------------------------------------------------------------
PRIMARY_FEATURES = ["T_adj", "S_eff", "F_t", "Pi_ind", "mu_k", "sigma_skill"]
LAGGED_FEATURES  = ["T_adj_lag1", "S_eff_lag1", "F_t_lag1", "Pi_lag1"]
COUPLING_FEATURES = ["tension_narrative", "skill_net_friction"]
BASELINE_EXTRA   = ["R_eff", "years_since_last_event"]

FEATURE_NAMES = PRIMARY_FEATURES + LAGGED_FEATURES + COUPLING_FEATURES + BASELINE_EXTRA
# Total: 6 + 4 + 2 + 2 = 14


# ===========================================================================
# 1. Build feature matrix from SixFactorOutputs
# ===========================================================================

def build_feature_matrix(
    country_outputs: Dict[str, SixFactorOutputs],
    labels_df: pd.DataFrame,
) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    """
    Assemble (X, y, meta) for ML training from SixFactorOutputs and labels.

    Parameters
    ----------
    country_outputs : dict  {iso3: SixFactorOutputs}
        Per-country model outputs from sd_model.compute_country_outputs().
    labels_df : pd.DataFrame
        Output of sd_labels.merge_labels_with_features(), must contain:
        country, year, instability_onset, years_since_last_event.

    Returns
    -------
    X    : np.ndarray  (n_samples, 14)  — feature matrix, NaN rows dropped
    y    : np.ndarray  (n_samples,)     — binary instability onset labels
    meta : pd.DataFrame  columns [country, year]  — for GroupKFold grouping
    """
    rows = []
    for iso, out in country_outputs.items():
        for year in out.T_adj.index:
            row = {"country": iso, "year": int(year)}
            # Six primary
            row["T_adj"]       = _safe(out.T_adj,       year)
            row["S_eff"]       = _safe(out.S_eff,       year)
            row["F_t"]         = _safe(out.F_t,         year)
            row["Pi_ind"]      = _safe(out.Pi_ind,      year)
            row["mu_k"]        = _safe(out.mu_k,        year)
            row["sigma_skill"] = _safe(out.sigma_skill, year)
            # Four lagged
            row["T_adj_lag1"]  = _safe(out.T_adj_lag1,  year)
            row["S_eff_lag1"]  = _safe(out.S_eff_lag1,  year)
            row["F_t_lag1"]    = _safe(out.F_t_lag1,    year)
            row["Pi_lag1"]     = _safe(out.Pi_lag1,     year)
            # Two coupling interactions
            row["tension_narrative"]  = _safe(out.tension_narrative,  year)
            row["skill_net_friction"] = _safe(out.skill_net_friction, year)
            # R_eff (baseline resource proxy)
            row["R_eff"] = _safe(out.R_eff, year)
            rows.append(row)

    features_df = pd.DataFrame(rows)

    # Merge with labels (gets instability_onset and years_since_last_event)
    labels_df = labels_df.copy()
    labels_df["country"] = labels_df["country"].astype(str).str.upper().str.strip()
    labels_df["year"] = labels_df["year"].astype(int)
    features_df["country"] = features_df["country"].astype(str).str.upper().str.strip()
    features_df["year"] = features_df["year"].astype(int)

    merged = features_df.merge(
        labels_df[["country", "year", "instability_onset", "years_since_last_event"]],
        on=["country", "year"],
        how="inner",
    )

    # Drop rows with NaN in any feature or label column
    all_feature_cols = FEATURE_NAMES
    merged = merged.dropna(subset=all_feature_cols + ["instability_onset"])

    if merged.empty:
        raise ValueError(
            "Feature matrix is empty after dropping NaN rows. "
            "Check that country_outputs and labels_df share overlapping country-years."
        )

    X    = merged[all_feature_cols].values.astype(float)
    y    = merged["instability_onset"].values.astype(int)
    meta = merged[["country", "year"]].reset_index(drop=True)

    pos = int(y.sum())
    neg = len(y) - pos
    print(f"[classifier] Feature matrix: {X.shape[0]} samples × {X.shape[1]} features")
    print(f"[classifier] Class balance: {pos} positive / {neg} negative "
          f"(ratio ≈ 1:{neg // pos if pos else '∞'})")

    return X, y, meta


def _safe(series: pd.Series, year: int) -> float:
    """Return series value at year, or NaN if missing."""
    try:
        val = series.loc[year]
        return float(val) if not pd.isna(val) else np.nan
    except Exception:
        return np.nan


# ===========================================================================
# 2. PITF 3-variable baseline
# ===========================================================================

def pitf_baseline_features(
    labels_df: pd.DataFrame,
    wdi_df: pd.DataFrame,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Replicate the Goldstone et al. (2010, AJPS) 3-variable PITF baseline model.

    Variables
    ---------
    polity_proxy          : PV.EST (WGI Political Stability) as ordinal regime proxy.
                            Note: Goldstone et al. use Polity IV; PV.EST is a WGI
                            composite expert survey, not a true polity score.
                            Approximation documented here — do not conflate.
    infant_mortality_proxy: SP.DYN.IMRT.IN (under-5 mortality rate per 1,000 live births).
                            Goldstone et al. use infant mortality rate; under-5 is the
                            closest WDI equivalent with good coverage.
    years_since_last_event: from labels_df (computed by sd_labels.add_years_since_event).

    Parameters
    ----------
    labels_df : pd.DataFrame  (must have: country, year, instability_onset,
                                          years_since_last_event)
    wdi_df    : pd.DataFrame  (raw WDI panel from sd_data.fetch_plan — must have
                                country, year, PV.EST, optionally SP.DYN.IMRT.IN)

    Returns
    -------
    X_baseline : np.ndarray  (n_samples, 3)
    y          : np.ndarray  (n_samples,)  binary instability onset
    """
    wdi_df = wdi_df.copy()
    wdi_df["country"] = wdi_df["country"].astype(str).str.upper().str.strip()
    wdi_df["year"] = wdi_df["year"].astype(int)

    labels_df = labels_df.copy()
    labels_df["country"] = labels_df["country"].astype(str).str.upper().str.strip()
    labels_df["year"] = labels_df["year"].astype(int)

    # Select WDI columns we need
    keep_cols = ["country", "year"]
    if "PV.EST" in wdi_df.columns:
        keep_cols.append("PV.EST")
    if "SP.DYN.IMRT.IN" in wdi_df.columns:
        keep_cols.append("SP.DYN.IMRT.IN")

    merged = labels_df.merge(
        wdi_df[keep_cols].drop_duplicates(["country", "year"]),
        on=["country", "year"],
        how="left",
    )

    # Construct 3-variable feature matrix
    # If any WDI column is missing, fill with 0 (not ideal, but keeps code running)
    if "PV.EST" not in merged.columns:
        merged["PV.EST"] = 0.0
        warnings.warn("[classifier] PV.EST not in WDI data; baseline polity_proxy = 0.")

    if "SP.DYN.IMRT.IN" not in merged.columns:
        merged["SP.DYN.IMRT.IN"] = 0.0
        warnings.warn("[classifier] SP.DYN.IMRT.IN not in WDI data; "
                      "infant_mortality_proxy = 0. Add INFANT_MORT to sd_config.INDICATORS.")

    if "years_since_last_event" not in merged.columns:
        merged["years_since_last_event"] = 0

    baseline_cols = ["PV.EST", "SP.DYN.IMRT.IN", "years_since_last_event"]
    merged = merged.dropna(subset=baseline_cols + ["instability_onset"])

    X_baseline = merged[baseline_cols].values.astype(float)
    y           = merged["instability_onset"].values.astype(int)
    return X_baseline, y


# ===========================================================================
# 3. Train & evaluate
# ===========================================================================

def train_evaluate(
    X: np.ndarray,
    y: np.ndarray,
    meta: pd.DataFrame,
    X_baseline: np.ndarray | None = None,
) -> dict:
    """
    Train XGBoost, Random Forest, and (optionally) PITF baseline logistic
    regression. Evaluate with GroupKFold(n_splits=5) grouped by country.

    Class imbalance strategy
    ------------------------
    Uses scale_pos_weight (XGBoost) and class_weight='balanced' (RF, LR).
    SMOTE is deliberately NOT used: van den Goorbergh et al. (JAMIA 2022)
    demonstrates that SMOTE degrades probability calibration for rare events
    without improving discrimination. Balanced weights maintain valid
    probability outputs, which are required for interpretable risk scores.

    Cross-validation
    ----------------
    GroupKFold by country prevents temporal autocorrelation leakage.
    Each fold holds out one or more countries entirely from training.

    Primary metric: AUPRC (precision-recall area). AUC-ROC is unreliable
    for imbalanced data because it is dominated by true negatives.
    Reference: Davis & Goadrich (2006), ICML.

    Parameters
    ----------
    X           : feature matrix (n_samples, 14)
    y           : binary labels (n_samples,)
    meta        : DataFrame with 'country' column, used for GroupKFold grouping
    X_baseline  : optional (n_samples, 3) PITF baseline features

    Returns
    -------
    dict with keys:
      'xgb_metrics', 'rf_metrics', 'lr_metrics' (if X_baseline provided),
      'xgb_final', 'rf_final'  — models fitted on full data
      'feature_names'
    """
    pos = int(y.sum())
    neg = len(y) - pos
    scale_pos_weight = neg / pos if pos > 0 else 1.0

    # ------------------------------------------------------------------
    # Model definitions
    # ------------------------------------------------------------------
    xgb_model = XGBClassifier(
        n_estimators=500,
        max_depth=4,
        learning_rate=0.05,
        scale_pos_weight=scale_pos_weight,
        eval_metric="aucpr",
        use_label_encoder=False,
        random_state=42,
        verbosity=0,
    )

    rf_model = RandomForestClassifier(
        n_estimators=300,
        class_weight="balanced",
        max_depth=6,
        random_state=42,
        n_jobs=-1,
    )

    # ------------------------------------------------------------------
    # Cross-validation
    # ------------------------------------------------------------------
    groups = meta["country"].values
    n_unique = len(np.unique(groups))
    n_splits = min(5, n_unique)  # can't have more folds than countries
    gkf = GroupKFold(n_splits=n_splits)

    print(f"\n[classifier] GroupKFold CV: {n_splits} folds × {n_unique} unique countries")

    xgb_scores  = _cross_val_scores(xgb_model, X, y, groups, gkf, model_name="XGB")
    rf_scores   = _cross_val_scores(rf_model,  X, y, groups, gkf, model_name="RF")

    lr_scores = None
    if X_baseline is not None and len(X_baseline) == len(y):
        lr_model = LogisticRegression(
            class_weight="balanced", max_iter=1000, random_state=42
        )
        lr_scores = _cross_val_scores(
            lr_model, X_baseline, y, groups, gkf, model_name="PITF-LR"
        )

    # ------------------------------------------------------------------
    # Print comparison table
    # ------------------------------------------------------------------
    _print_comparison_table(xgb_scores, rf_scores, lr_scores)

    # ------------------------------------------------------------------
    # Final models fitted on full data
    # ------------------------------------------------------------------
    print("\n[classifier] Fitting final models on full dataset ...")
    xgb_final = XGBClassifier(
        n_estimators=500, max_depth=4, learning_rate=0.05,
        scale_pos_weight=scale_pos_weight, eval_metric="aucpr",
        use_label_encoder=False, random_state=42, verbosity=0,
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        xgb_final.fit(X, y)

    rf_final = RandomForestClassifier(
        n_estimators=300, class_weight="balanced", max_depth=6,
        random_state=42, n_jobs=-1,
    )
    rf_final.fit(X, y)
    print("[classifier] Final models fitted.")

    return {
        "xgb_metrics":   xgb_scores,
        "rf_metrics":    rf_scores,
        "lr_metrics":    lr_scores,
        "xgb_final":     xgb_final,
        "rf_final":      rf_final,
        "feature_names": FEATURE_NAMES,
    }


def _cross_val_scores(
    model,
    X: np.ndarray,
    y: np.ndarray,
    groups: np.ndarray,
    gkf: GroupKFold,
    model_name: str = "",
) -> dict:
    """Run GroupKFold CV and collect AUPRC, AUC-ROC, F1 per fold."""
    auprc_scores, aucroc_scores, f1_scores = [], [], []

    for fold, (train_idx, test_idx) in enumerate(gkf.split(X, y, groups)):
        X_tr, X_te = X[train_idx], X[test_idx]
        y_tr, y_te = y[train_idx], y[test_idx]

        if len(np.unique(y_te)) < 2:
            # Fold has only one class — skip (can happen with very few countries)
            continue

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            model.fit(X_tr, y_tr)
            y_prob = model.predict_proba(X_te)[:, 1]
            y_pred = model.predict(X_te)

        auprc_scores.append(average_precision_score(y_te, y_prob))
        aucroc_scores.append(roc_auc_score(y_te, y_prob))
        f1_scores.append(f1_score(y_te, y_pred, pos_label=1, zero_division=0))

    return {
        "model_name": model_name,
        "auprc":  (np.mean(auprc_scores),  np.std(auprc_scores)),
        "aucroc": (np.mean(aucroc_scores), np.std(aucroc_scores)),
        "f1":     (np.mean(f1_scores),     np.std(f1_scores)),
        "n_folds": len(auprc_scores),
    }


def _print_comparison_table(xgb: dict, rf: dict, lr: dict | None) -> None:
    """Print formatted model comparison table."""
    header = f"\n{'Model':<22} | {'AUPRC':^15} | {'AUC-ROC':^15} | {'F1 (instability)':^15}"
    sep    = "-" * len(header)
    print(sep)
    print(header)
    print(sep)

    def fmt(scores: dict) -> str:
        name = scores["model_name"]
        auprc  = f"{scores['auprc'][0]:.3f} ± {scores['auprc'][1]:.3f}"
        aucroc = f"{scores['aucroc'][0]:.3f} ± {scores['aucroc'][1]:.3f}"
        f1     = f"{scores['f1'][0]:.3f} ± {scores['f1'][1]:.3f}"
        return f"{name:<22} | {auprc:^15} | {aucroc:^15} | {f1:^15}"

    rows = []
    if lr is not None:
        rows.append(fmt(lr))
    rows.append(fmt(rf))
    rows.append(fmt(xgb))
    for row in rows:
        print(row)
    print(sep)


# ===========================================================================
# 4. SHAP interpretability
# ===========================================================================

def shap_analysis(
    model,
    X: np.ndarray,
    feature_names: list[str],
    out_dir: str = "out",
) -> dict:
    """
    SHAP feature importance analysis for the trained XGBoost model.

    Produces two plots:
      - Beeswarm plot: distribution of SHAP values per feature (direction + magnitude)
      - Bar chart: mean |SHAP| value per feature (overall importance ranking)

    Returns
    -------
    dict  {feature_name: mean_abs_shap}  sorted descending
    """
    os.makedirs(out_dir, exist_ok=True)

    print("\n[shap] Computing SHAP values ...")
    explainer = shap.TreeExplainer(model)

    X_df = pd.DataFrame(X, columns=feature_names)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        shap_vals = explainer.shap_values(X_df)

    # Handle different shap output formats:
    # - 2D array (n_samples, n_features) for binary XGB
    # - list of two 2D arrays (one per class) — take positive class
    if isinstance(shap_vals, list):
        sv = shap_vals[1] if len(shap_vals) == 2 else shap_vals[0]
    else:
        sv = shap_vals

    mean_abs = np.abs(sv).mean(axis=0)
    importance = dict(zip(feature_names, mean_abs))
    importance_sorted = dict(sorted(importance.items(), key=lambda x: x[1], reverse=True))

    # ------------------------------------------------------------------
    # Beeswarm plot
    # ------------------------------------------------------------------
    try:
        shap_exp = shap.Explanation(
            values=sv,
            base_values=explainer.expected_value
                if not isinstance(explainer.expected_value, np.ndarray)
                else explainer.expected_value[1],
            data=X_df.values,
            feature_names=feature_names,
        )
        fig_bee, ax_bee = plt.subplots(figsize=(9, 6))
        shap.plots.beeswarm(shap_exp, max_display=14, show=False)
        fig_bee = plt.gcf()
        fig_bee.tight_layout()
        bee_path = os.path.join(out_dir, "shap_beeswarm.png")
        fig_bee.savefig(bee_path, dpi=150, bbox_inches="tight")
        plt.close(fig_bee)
        print(f"[shap] Beeswarm saved → {bee_path}")
    except Exception as e:
        print(f"[shap] Beeswarm plot failed: {e}")

    # ------------------------------------------------------------------
    # Mean |SHAP| bar chart
    # ------------------------------------------------------------------
    fig_bar, ax_bar = plt.subplots(figsize=(8, 5))
    names_sorted = list(importance_sorted.keys())
    vals_sorted  = list(importance_sorted.values())
    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(names_sorted)))[::-1]
    ax_bar.barh(names_sorted[::-1], vals_sorted[::-1], color=colors[::-1])
    ax_bar.set_xlabel("Mean |SHAP value|", fontsize=11)
    ax_bar.set_title("Feature Importance (SHAP) — StateDynamics XGB", fontsize=12)
    ax_bar.axvline(0, color="black", linewidth=0.5)
    plt.tight_layout()
    bar_path = os.path.join(out_dir, "shap_importance.png")
    fig_bar.savefig(bar_path, dpi=150)
    plt.close(fig_bar)
    print(f"[shap] Importance bar chart saved → {bar_path}")

    # Print top features
    print("\n[shap] Top feature importances (mean |SHAP|):")
    for name, val in list(importance_sorted.items())[:10]:
        print(f"  {name:<25}  {val:.4f}")

    return importance_sorted
