"""
sd_run.py — CHN/AUS/USA/SGP/HKG end-to-end with progress & checks
=================================================================
改动要点：
- 阶段进度打印（抓数→合并→计算→出图→汇总）
- 异常不中断：单国失败不影响其他国家
- 覆盖率和缺失报告：out/coverage_percent.csv
- 运行日志：out/run_log.txt
"""
from __future__ import annotations
import os, sys, traceback
import pandas as pd
from sd_config import COUNTRIES, YEAR_START, YEAR_END, INDICATORS, WEIGHTS, B_WEIGHTS, ETA_E, MU_K, HAWKES, PI_INDIVIDUAL, R_MIN, S_MIN
from sd_data import WBFetchPlan, fetch_plan, to_country_dict
from sd_model import compute_country_outputs
from sd_visualize import plot_series, plot_bar_latest

LOG_PATH = os.path.join("out", "run_log.txt")

def _log(msg: str, also_print: bool = True) -> None:
    os.makedirs("out", exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(msg.rstrip() + "\n")
    if also_print:
        print(msg, flush=True)

def _report_coverage(df: pd.DataFrame) -> pd.DataFrame:
    """
    按国家×指标计算数据覆盖百分比（非 NaN 占比），写到 out/coverage_percent.csv。
    修复点：不要在 groupby 前先丢掉 'year'，否则 set_index('year') 会找不到。
    """
    # 指标列 = 除去键列
    ind_cols = [c for c in df.columns if c not in ("country", "year")]

    # 兜底：如果 year 不在列但在索引里，复位；如果完全没有 year，就忽略 year 直接算覆盖。
    if "year" not in df.columns:
        if "year" in getattr(df.index, "names", []):
            df = df.reset_index()
        else:
            cov = df.groupby("country")[ind_cols].apply(lambda g: g.notna().mean() * 100.0)
            cov.to_csv(os.path.join("out", "coverage_percent.csv"))
            return cov

    # 正常路径：保留 year，再按国家分组，在组内以 year 为索引算覆盖率
    cov = (
        df.groupby("country")
          .apply(lambda g: g.set_index("year")[ind_cols].notna().mean() * 100.0)
    )
    cov.to_csv(os.path.join("out", "coverage_percent.csv"))
    return cov


def main():
    os.makedirs("out", exist_ok=True)
    # 清空旧日志
    open(LOG_PATH, "w").close()

    try:
        _log("=== Stage 1/6: Building fetch plan ===")
        indicators = list(INDICATORS.values())
        plan = WBFetchPlan(countries=COUNTRIES, indicators=indicators, start=YEAR_START, end=YEAR_END)

        _log("=== Stage 2/6: Fetching data from World Bank (with retry/backoff/cache) ===")
        df = fetch_plan(plan, verbose=True)
        if df.empty:
            _log("[FATAL] No data acquired. Check network/VPN or populate cache/ directory.", also_print=True)
            return

        _log(f"[OK] Downloaded rows: {len(df)}")
        _log("=== Stage 3/6: Computing coverage report ===")
        cov = _report_coverage(df)
        _log("[OK] Coverage report saved -> out/coverage_percent.csv")

        _log("=== Stage 4/6: Per-country computation & plots ===")
        country_dfs = to_country_dict(df)
        records = []
        latest_pi = {}
        country_outputs = {}   # {iso: SixFactorOutputs} — used in Stage 5 & 6

        for i, iso in enumerate(COUNTRIES, start=1):
            if iso not in country_dfs:
                _log(f"[WARN] Missing country frame: {iso} — skipped")
                continue
            _log(f"[{i}/{len(COUNTRIES)}] Computing {iso} ...")
            cdf = country_dfs[iso]
            try:
                out = compute_country_outputs(
                    cdf, weights=WEIGHTS, Bw=B_WEIGHTS, eta_cfg=ETA_E, mu_cfg=MU_K,
                    hawkes_cfg=HAWKES, psi_cfg=PI_INDIVIDUAL, R_min=R_MIN, S_min=S_MIN
                )
                # 出图
                plot_series(out.T_adj, f"{iso} — T_adj (Adjusted Tension)", "T_adj (z-scaled)", os.path.join("out", f"{iso}_T_adj.png"))
                plot_series(out.S_eff, f"{iso} — S_eff (Effective Narrative)", "S_eff (0..2 approx)", os.path.join("out", f"{iso}_S_eff.png"))
                plot_series(out.F_t,  f"{iso} — F(t) (Shock Convolution)",   "F(t) (0..1)",          os.path.join("out", f"{iso}_F_t.png"))
                # 记录
                for y in cdf.index:
                    records.append({
                        "country": iso, "year": int(y),
                        "T_adj": float(out.T_adj.loc[y]) if y in out.T_adj.index else None,
                        "S_eff": float(out.S_eff.loc[y]) if y in out.S_eff.index else None,
                        "F_t":   float(out.F_t.loc[y])    if y in out.F_t.index    else None,
                        "Pi_ind":float(out.Pi_ind.loc[y]) if y in out.Pi_ind.index else None,
                    })
                latest_year = int(cdf.index.max()) if len(cdf.index) else None
                if latest_year is not None and latest_year in out.Pi_ind.index:
                    latest_pi[iso] = float(out.Pi_ind.loc[latest_year])
                country_outputs[iso] = out
                _log(f"[OK] {iso} done.")
            except Exception as e:
                _log(f"[ERROR] {iso} failed: {e}")
                traceback.print_exc()
                continue

        if not records:
            _log("[FATAL] No country outputs produced. Aborting.")
            return

        # 保存长表
        long = pd.DataFrame.from_records(records).sort_values(["country", "year"])
        long.to_csv(os.path.join("out", "metrics_long.csv"), index=False)
        _log("[OK] Saved -> out/metrics_long.csv")

        # 横向条形图
        if latest_pi:
            latest_series = pd.Series(latest_pi).sort_values(ascending=False)
            plot_bar_latest(latest_series, "Π_ind (latest year) — cross-country", "Π_ind (unitless, higher=better for individual)", os.path.join("out", "Pi_ind_latest_bar.png"))
            _log("[OK] Saved -> out/Pi_ind_latest_bar.png")
            _log("=== Stage 4 Summary: latest Π_ind (individual opportunity) ===")
            for iso, val in latest_series.items():
                try:
                    _log(f"{iso}: Π_ind={val:+.3f}")
                except Exception:
                    _log(f"{iso}: Π_ind={val}")
        else:
            _log("[WARN] No latest Π_ind values to plot.")

        # ==============================================================
        # Stage 5/6: Granger coupling check
        # ==============================================================
        _log("=== Stage 5/6: Granger inter-factor coupling check ===")
        try:
            from sd_coupling_check import run_granger_matrix
            granger_results = run_granger_matrix(country_outputs, out_dir="out")
            _log("[OK] Granger matrix saved -> out/granger_coupling_matrix.png")
            _log("Empirically supported coupling pairs (sig_fraction > 0.30):")
            FACTORS = ["T_adj", "S_eff", "F_t", "Pi_ind", "mu_k", "sigma_skill"]
            for cause in FACTORS:
                for effect in FACTORS:
                    if cause == effect:
                        continue
                    frac = granger_results.loc[effect, cause] if (
                        effect in granger_results.index and cause in granger_results.columns
                    ) else 0.0
                    if frac > 0.30:
                        _log(f"  {cause} → {effect}  (sig_fraction={frac:.2f})")
        except Exception as e:
            _log(f"[WARN] Stage 5 (Granger) failed: {e} — continuing.")
            traceback.print_exc()

        # ==============================================================
        # Stage 6/6: ML classification pipeline
        # ==============================================================
        _log("=== Stage 6/6: ML classification (XGB / RF / PITF baseline) ===")
        try:
            from sd_labels import load_pitf_labels, add_years_since_event, merge_labels_with_features
            from sd_classifier import (
                build_feature_matrix, pitf_baseline_features,
                train_evaluate, shap_analysis, FEATURE_NAMES,
            )

            # --- Labels (fallback to PV.EST proxy if no PITF CSV) ---
            labels = load_pitf_labels(filepath=None)
            if labels.empty:
                _log("[WARN] No labels available — skipping ML stage.")
            else:
                labels = add_years_since_event(labels)

                # long DataFrame (Stage 4 output) has country + year + factors
                # merge_labels_with_features aligns it with instability_onset
                merged = merge_labels_with_features(long, labels)
                _log(f"[OK] Merged dataset: {len(merged)} rows")

                # Build feature matrix from full SixFactorOutputs
                X, y, meta = build_feature_matrix(country_outputs, merged)
                _log(f"[OK] Feature matrix: {X.shape[0]} samples × {X.shape[1]} features")

                # PITF 3-variable baseline (Goldstone et al. 2010)
                try:
                    X_baseline, _ = pitf_baseline_features(merged, df)
                except Exception as be:
                    _log(f"[WARN] PITF baseline failed: {be} — training without baseline comparison.")
                    X_baseline = None

                # Train + evaluate
                results = train_evaluate(X, y, meta, X_baseline=X_baseline)
                _log("[OK] Model training complete.")

                # SHAP interpretability
                best_model = results["xgb_final"]
                shap_analysis(best_model, X, FEATURE_NAMES, out_dir="out")
                _log("[OK] SHAP plots saved -> out/shap_beeswarm.png, out/shap_importance.png")

                # Save predictions on full dataset
                import numpy as np
                proba = best_model.predict_proba(X)[:, 1]
                pred_df = meta.copy()
                pred_df["instability_prob"] = proba
                pred_df["instability_pred"] = (proba >= 0.5).astype(int)
                pred_df.to_csv(os.path.join("out", "instability_predictions.csv"), index=False)
                _log("[OK] Predictions saved -> out/instability_predictions.csv")

        except Exception as e:
            _log(f"[WARN] Stage 6 (ML) failed: {e} — check logs for details.")
            traceback.print_exc()

        _log("All done.")

    except Exception as e:
        _log(f"[FATAL] Unhandled error: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()
