"""
sd_model.py — Theory-to-code transforms (refactored v0.4)
----------------------------------------------------------
Six-factor model for political instability prediction:
  T_adj   — Adjusted social tension (wealth gap + cultural gap + security gap,
             modulated by elite concession)
  S_eff   — Effective narrative bandwidth (information environment)
  F(t)    — External shock convolution (Hawkes-like decay)
  Pi_ind  — Individual opportunity (skill − friction + capital − tax)
  mu_k    — Cross-jurisdiction friction
  sigma   — Skill supply

Refactor changes from v0.3:
  FIX A — Unified panel_zscore normalization (removes mixed zscore/minmax arithmetic)
  FIX B — VA.EST removed from latent_B() to eliminate multicollinearity with ΔC
  FIX C — R_eff now computed from data (GFCF × tax burden), not hardcoded to 1.0
  FIX D — Coupling / interaction terms added (tension_narrative, skill_net_friction)
           and lagged factors (T_adj_lag1, S_eff_lag1, F_t_lag1, Pi_lag1)

References:
  Goldstone et al. (2010, AJPS) — PITF 3-variable baseline
  Turchin (2003) — Structural-demographic theory, state fiscal health
  Gurr (1970) — Relative deprivation and narrative-tension coupling
  Hegre & Sambanis (2006) — Conflict onset predictors
"""
from __future__ import annotations

import math
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# ===========================================================================
# Normalisation utilities
# ===========================================================================

def panel_zscore(series: pd.Series, country_index: pd.Index) -> pd.Series:
    """
    Two-step normalisation for panel data.

    Step 1: Within-country demeaning (removes country fixed effects).
    Step 2: Cross-sectional standardisation (makes units comparable).

    This follows standard practice in political economy panel regressions.
    When called inside a groupby (per-country), the series is already
    country-specific so Step 1 removes that country's mean and Step 2
    standardises relative to its own variance.

    Parameters
    ----------
    series : pd.Series
        The raw indicator series (already per-country when called from
        compute_country_outputs).
    country_index : pd.Index
        Passed for documentation / future panel-level use; not used
        in the current per-country call pattern.

    Returns
    -------
    pd.Series
        Demeaned and standardised series. Returns 0.0 series if constant
        or all-NaN.
    """
    series = series.astype(float)
    demeaned = series - series.mean(skipna=True)
    std = demeaned.std(skipna=True)
    if pd.isna(std) or std == 0:
        return pd.Series(0.0, index=series.index)
    return demeaned / std


def zscore(x: pd.Series) -> pd.Series:
    """Legacy helper — kept for backwards compatibility with sd_visualize etc."""
    x = x.astype(float)
    mu = x.mean(skipna=True)
    sd = x.std(skipna=True)
    if sd == 0 or pd.isna(sd):
        return pd.Series(0.0, index=x.index)
    return (x - mu) / sd


def minmax01(x: pd.Series) -> pd.Series:
    """Legacy helper — kept for backwards compatibility."""
    x = x.astype(float)
    lo, hi = x.min(skipna=True), x.max(skipna=True)
    if pd.isna(lo) or pd.isna(hi) or hi == lo:
        return pd.Series(0.0, index=x.index)
    return (x - lo) / (hi - lo)


def year_over_year(x: pd.Series) -> pd.Series:
    return x.astype(float).diff(1)


# ===========================================================================
# Factor composites
# ===========================================================================

def latent_B(
    internet_users: pd.Series,
    mobile_subs: Optional[pd.Series] = None,
    wI: float = 0.7,
    wM: float = 0.3,
) -> pd.Series:
    """
    B(t): latent narrative bandwidth index.

    Combines internet penetration and mobile subscription density as proxies
    for the population's exposure to information flows. Mapped to (0, 1) via
    logistic function.

    Parameters
    ----------
    internet_users : pd.Series  (IT.NET.USER.ZS — % of population)
    mobile_subs    : pd.Series  (IT.CEL.SETS.P2 — per 100 people), optional
    wI, wM         : float weights (must sum to 1.0)

    Notes
    -----
    VA.EST (Voice & Accountability) has been deliberately removed from this
    function. VA.EST measures political voice/accountability, which is the
    ΔC (cultural legitimacy gap) component of the tension equation. Including
    it here also would make B(t) partly capture the same variance as ΔC,
    creating multicollinearity that inflates apparent model fit.
    """
    zI = panel_zscore(internet_users, internet_users.index)
    zM = (
        panel_zscore(mobile_subs, mobile_subs.index)
        if mobile_subs is not None
        else pd.Series(0.0, index=zI.index)
    )
    lin = wI * zI + wM * zM
    return 1.0 / (1.0 + np.exp(-lin))  # sigmoid → (0, 1)


def eta_E(
    ge_est: pd.Series,
    rq_est: pd.Series,
    rl_est: pd.Series,
    cc_est: pd.Series,
    window: int = 3,
    w_ge: float = 0.3,
    w_rq: float = 0.3,
    w_rl: float = 0.2,
    w_cc: float = 0.2,
) -> pd.Series:
    """
    Elite concession index η_E.

    Positive-only year-over-year changes in governance indicators (GE, RQ, RL, CC)
    averaged over a rolling window. A positive value means institutions are
    improving, which theoretically dampens social tension.

    Returns a panel_zscore-normalised series (z-scale, not bounded 0..1).
    """
    d_ge = year_over_year(ge_est).clip(lower=0.0)
    d_rq = year_over_year(rq_est).clip(lower=0.0)
    d_rl = year_over_year(rl_est).clip(lower=0.0)
    d_cc = year_over_year(cc_est).clip(lower=0.0)
    raw = w_ge * d_ge + w_rq * d_rq + w_rl * d_rl + w_cc * d_cc
    ma = raw.rolling(window=window, min_periods=1).mean()
    return panel_zscore(ma, ma.index)


def mu_k(
    fdi_pct_gdp: pd.Series,
    rq_est: pd.Series,
    w_neg_fdi: float = 0.6,
    w_neg_rq: float = 0.4,
) -> pd.Series:
    """
    Cross-jurisdiction friction μ_k.

    Low FDI inflows and weak regulatory quality both signal high barriers
    to cross-border capital and skill mobility. Returns a panel_zscore-
    normalised series (higher value = more friction).
    """
    z_neg_fdi = panel_zscore(-fdi_pct_gdp, fdi_pct_gdp.index)
    z_neg_rq = panel_zscore(-rq_est, rq_est.index)
    raw = w_neg_fdi * z_neg_fdi + w_neg_rq * z_neg_rq
    return panel_zscore(raw, raw.index)


def sigma_skill(
    rnd_gdp: pd.Series,
    researchers_pm: pd.Series,
    tertiary_enroll: pd.Series,
) -> pd.Series:
    """
    Skill supply index σ.

    Composite of R&D spending (% GDP), research personnel (per million),
    and tertiary enrolment rate. All components panel_zscored before
    summation so that different units are comparable.
    """
    comp = (
        panel_zscore(rnd_gdp, rnd_gdp.index)
        + panel_zscore(researchers_pm, researchers_pm.index)
        + panel_zscore(tertiary_enroll, tertiary_enroll.index)
    )
    return panel_zscore(comp, comp.index)


def rho_Mdot_from_gfcf(gfcf_pct_gdp: pd.Series) -> pd.Series:
    """
    Capital velocity proxy ρṀ.

    Year-over-year change in gross fixed capital formation (% GDP),
    normalised via panel_zscore. Positive values indicate accelerating
    capital formation (favourable for opportunity).
    """
    d = year_over_year(gfcf_pct_gdp)
    return panel_zscore(d, d.index)


def psi_tax(tax_pct_gdp: pd.Series, scale: float = 1.0) -> pd.Series:
    """
    Tax burden proxy ψ_tax.

    Higher tax as share of GDP proxies extraction burden on individuals.
    Normalised via panel_zscore and scaled; enters Π_ind with a negative sign.
    """
    return panel_zscore(tax_pct_gdp.astype(float), tax_pct_gdp.index) * scale


def compute_R_eff(
    gfcf_pct_gdp: pd.Series,
    tax_pct_gdp: pd.Series,
) -> pd.Series:
    """
    Material resource availability proxy R_eff ∈ [0, 1].

    R_eff = (capital formation rate) × (1 − tax burden)

    Interpretation: higher gross fixed capital formation net of tax extraction
    indicates more resources available for state/population reproduction.
    Clipped to [0, 1] for use in the collapse condition threshold.

    Source: conceptually aligned with Turchin's 'state fiscal health'
    component in structural-demographic theory (Turchin 2003, Historical
    Dynamics).
    """
    gfcf_norm = panel_zscore(gfcf_pct_gdp, gfcf_pct_gdp.index)
    tax_norm = panel_zscore(tax_pct_gdp, tax_pct_gdp.index)
    # Map z-scores to (0, 1) before combining
    r = (gfcf_norm + 1) / 2 * (1 - (tax_norm + 1) / 2)
    return r.clip(0, 1)


# ===========================================================================
# Shock detection & Hawkes convolution
# ===========================================================================

def detect_shock_events(
    df: pd.DataFrame,
    cols: List[str],
    z_threshold: float = 2.0,
    max_events_per_year: int = 3,
) -> List[Tuple[int, float]]:
    """
    Identify anomalous year-over-year jumps across multiple indicator series.

    Returns a list of (year, amplitude) tuples representing shock events.
    """
    if not cols:
        return []
    zsum = None
    for c in cols:
        if c not in df.columns:
            continue
        dz = zscore(df[c].astype(float).diff(1)).abs()
        zsum = dz if zsum is None else zsum.add(dz, fill_value=0.0)
    if zsum is None:
        return []

    events = [
        (int(y), float(zval))
        for y, zval in zsum.items()
        if not pd.isna(zval) and zval >= z_threshold
    ]

    by_year: Dict[int, List[float]] = {}
    for y, a in events:
        by_year.setdefault(y, []).append(a)

    pruned: List[Tuple[int, float]] = []
    for y, arr in by_year.items():
        for a in sorted(arr, reverse=True)[:max_events_per_year]:
            pruned.append((y, a))
    return sorted(pruned, key=lambda t: t[0])


def hawkes_convolution(
    year_index: List[int],
    events: List[Tuple[int, float]],
    lam: float = 0.45,
) -> pd.Series:
    """
    F(t) = Σ A_k · exp(−λ (t − t_k)) for t ≥ t_k, normalised to [0, 1].

    Hawkes-like decay: each shock contributes exponentially decaying intensity.
    """
    years = list(year_index)
    out = pd.Series(0.0, index=years, dtype=float)
    for y in years:
        acc = sum(
            ak * math.exp(-lam * (y - tk))
            for (tk, ak) in events
            if y >= tk
        )
        out.loc[y] = acc
    return minmax01(out)


# ===========================================================================
# Six-Factor outputs dataclass
# ===========================================================================

@dataclass
class SixFactorOutputs:
    # Primary factors
    T_adj:    pd.Series
    S_eff:    pd.Series
    F_t:      pd.Series
    Pi_ind:   pd.Series
    mu_k:     pd.Series
    sigma_skill: pd.Series
    R_eff:    pd.Series

    # Coupling / interaction terms (FIX D)
    tension_narrative:  pd.Series   # T_adj × B_t
    skill_net_friction: pd.Series   # sigma × (1 − mu_k normalised to [0,1])

    # Lagged factors t-1  (standard in conflict prediction, Hegre & Sambanis 2006)
    T_adj_lag1: pd.Series
    S_eff_lag1: pd.Series
    F_t_lag1:   pd.Series
    Pi_lag1:    pd.Series

    # Collapse flag
    collapse:   pd.Series   # bool series — R_eff < R_MIN or S_eff < S_MIN

    # Diagnostic components dict (for plotting / inspection)
    components: Dict[str, pd.Series] = field(default_factory=dict)


# ===========================================================================
# Main per-country computation
# ===========================================================================

def compute_country_outputs(
    df: pd.DataFrame,
    weights: Dict[str, float],
    Bw: Dict[str, float],
    eta_cfg: Dict[str, float],
    mu_cfg: Dict[str, float],
    hawkes_cfg: Dict[str, float],
    psi_cfg: Dict[str, float],
    R_min: float = 0.20,
    S_min: float = 0.30,
) -> SixFactorOutputs:
    """
    Compute all six factors plus coupling terms for a single country.

    Parameters
    ----------
    df          : per-country DataFrame with year as index, columns = WDI/WGI codes
    weights     : {'alpha_W', 'beta_C', 'gamma_S'} — tension factor weights
    Bw          : {'wI', 'wM'} — B(t) component weights (wV removed — FIX B)
    eta_cfg     : rolling window and weights for η_E
    mu_cfg      : weights for μ_k
    hawkes_cfg  : {'lambda', 'z_threshold', 'max_events_per_year'}
    psi_cfg     : {'psi_tax_scale'}
    R_min       : collapse threshold for R_eff (default 0.20)
    S_min       : collapse threshold for S_eff (default 0.30)

    Returns
    -------
    SixFactorOutputs
    """
    def _get(col: str) -> pd.Series:
        s = df.get(col)
        return s if s is not None else pd.Series(0.0, index=df.index)

    # -----------------------------------------------------------------------
    # Raw indicators
    # -----------------------------------------------------------------------
    gini       = _get("SI.POV.GINI")
    va         = _get("VA.EST")
    homicide   = _get("VC.IHR.PSRC.P5")
    inet       = _get("IT.NET.USER.ZS")
    mobile     = df.get("IT.CEL.SETS.P2")          # optional → None ok
    ge, rq     = _get("GE.EST"), _get("RQ.EST")
    rl, cc     = _get("RL.EST"), _get("CC.EST")
    pv         = _get("PV.EST")
    gfcf       = _get("NE.GDI.FTOT.ZS")
    fdi        = _get("BX.KLT.DINV.WD.GD.ZS")
    tax        = _get("GC.TAX.TOTL.GD.ZS")
    rnd_gdp    = _get("GB.XPD.RSDV.GD.ZS")
    researchers= _get("SP.POP.SCIE.RD.P6")
    tertiary   = _get("SE.TER.ENRR")

    # -----------------------------------------------------------------------
    # Δ variables — annual changes, then panel_zscore for comparability
    # -----------------------------------------------------------------------
    dW_raw = year_over_year(gini)
    # ΔC: declining Voice & Accountability → cultural legitimacy gap increases
    dC_raw = -year_over_year(va)
    # ΔS: rising homicide, or declining political stability as fallback
    has_homicide = (homicide != 0).any()
    dS_raw = (
        year_over_year(homicide) if has_homicide
        else -year_over_year(pv)
    )

    dW = panel_zscore(dW_raw, dW_raw.index)
    dC = panel_zscore(dC_raw, dC_raw.index)
    dS = panel_zscore(dS_raw, dS_raw.index)

    # -----------------------------------------------------------------------
    # η_E — Elite concession (panel_zscore normalised)
    # -----------------------------------------------------------------------
    eta = eta_E(
        ge, rq, rl, cc,
        window=int(eta_cfg.get("window_years", 3)),
        w_ge=float(eta_cfg.get("w_ge", 0.3)),
        w_rq=float(eta_cfg.get("w_rq", 0.3)),
        w_rl=float(eta_cfg.get("w_rl", 0.2)),
        w_cc=float(eta_cfg.get("w_cc", 0.2)),
    )

    # -----------------------------------------------------------------------
    # T and T_adj
    # -----------------------------------------------------------------------
    alpha = weights["alpha_W"]
    beta  = weights["beta_C"]
    gamma = weights["gamma_S"]

    T = alpha * dW + beta * dC + gamma * dS
    T_adj = T * (1.0 - eta.fillna(0.0))

    # -----------------------------------------------------------------------
    # B(t) — narrative bandwidth  (VA.EST removed — FIX B)
    # -----------------------------------------------------------------------
    B_t = latent_B(
        internet_users=inet,
        mobile_subs=mobile,
        wI=float(Bw.get("wI", 0.7)),
        wM=float(Bw.get("wM", 0.3)),
    )

    # -----------------------------------------------------------------------
    # S_eff — effective narrative bandwidth
    # -----------------------------------------------------------------------
    S_local  = panel_zscore(inet, inet.index)
    S_import = panel_zscore(va, va.index)
    S_eff = S_local + B_t * S_import

    # -----------------------------------------------------------------------
    # μ_k, σ_skill, ρṀ, ψ_tax  →  Π_ind
    # -----------------------------------------------------------------------
    mu     = mu_k(fdi, rq,
                  w_neg_fdi=float(mu_cfg["w_neg_fdi"]),
                  w_neg_rq=float(mu_cfg["w_neg_rq"]))
    sigma  = sigma_skill(rnd_gdp, researchers, tertiary)
    rho    = rho_Mdot_from_gfcf(gfcf)
    psi    = psi_tax(tax, scale=float(psi_cfg.get("psi_tax_scale", 1.0)))

    Pi = sigma.fillna(0.0) - mu.fillna(0.0) + rho.fillna(0.0) - psi.fillna(0.0)

    # -----------------------------------------------------------------------
    # R_eff — material resource availability  (FIX C)
    # -----------------------------------------------------------------------
    R_eff = compute_R_eff(gfcf, tax)

    # -----------------------------------------------------------------------
    # Shocks & F(t)
    # -----------------------------------------------------------------------
    shock_cols = [
        c for c in ["NY.GDP.MKTP.KD.ZG", "VC.IHR.PSRC.P5",
                     "BX.KLT.DINV.WD.GD.ZS", "PV.EST"]
        if c in df.columns
    ]
    events = detect_shock_events(
        df, shock_cols,
        z_threshold=float(hawkes_cfg["z_threshold"]),
        max_events_per_year=int(hawkes_cfg["max_events_per_year"]),
    )
    F_t = hawkes_convolution(list(df.index), events, lam=float(hawkes_cfg["lambda"]))

    # -----------------------------------------------------------------------
    # FIX D — Coupling / Interaction Terms
    # -----------------------------------------------------------------------
    # Interaction 1: High tension is amplified when information flows freely
    # (open narrative environment allows grievances to coordinate)
    # Reference: narrative-tension coupling in Gurr (1970).
    tension_narrative = T_adj * B_t

    # Interaction 2: Skill advantage is diminished by jurisdictional barriers
    # (human capital cannot translate to opportunity if mobility is restricted)
    # Map mu (z-scale) to a [0,1] friction factor via sigmoid before subtraction
    mu_01 = 1.0 / (1.0 + np.exp(-mu.fillna(0.0)))   # sigmoid → (0, 1)
    skill_net_friction = sigma * (1.0 - mu_01)

    # Lagged terms (t-1): prior year state predicts current onset
    # Standard in conflict prediction literature (Hegre & Sambanis 2006).
    T_adj_lag1 = T_adj.shift(1)
    S_eff_lag1 = S_eff.shift(1)
    F_t_lag1   = F_t.shift(1)
    Pi_lag1    = Pi.shift(1)

    # -----------------------------------------------------------------------
    # Collapse condition  (FIX C)
    # -----------------------------------------------------------------------
    collapse = (R_eff < R_min) | (S_eff < S_min)

    # -----------------------------------------------------------------------
    # Align helper & diagnostics
    # -----------------------------------------------------------------------
    def _align(s: pd.Series) -> pd.Series:
        return s.reindex(df.index).astype(float)

    events_count = pd.Series(0, index=df.index, dtype=int)
    for y, _a in events:
        if y in events_count.index:
            events_count.loc[y] += 1

    components = {
        "T": T, "eta_E": eta, "B_t": B_t,
        "S_local": S_local, "S_import": S_import,
        "mu_k": mu, "sigma_skill": sigma,
        "rho_Mdot": rho, "psi_tax": psi,
        "dW": dW, "dC": dC, "dS": dS,
        "R_eff": R_eff,
        "tension_narrative": tension_narrative,
        "skill_net_friction": skill_net_friction,
        "T_adj_lag1": T_adj_lag1,
        "S_eff_lag1": S_eff_lag1,
        "F_t_lag1": F_t_lag1,
        "Pi_lag1": Pi_lag1,
        "collapse": collapse.astype(float),
        "events_count": events_count.astype(float),
    }

    return SixFactorOutputs(
        T_adj=_align(T_adj),
        S_eff=_align(S_eff),
        F_t=_align(F_t),
        Pi_ind=_align(Pi),
        mu_k=_align(mu),
        sigma_skill=_align(sigma),
        R_eff=_align(R_eff),
        tension_narrative=_align(tension_narrative),
        skill_net_friction=_align(skill_net_friction),
        T_adj_lag1=_align(T_adj_lag1),
        S_eff_lag1=_align(S_eff_lag1),
        F_t_lag1=_align(F_t_lag1),
        Pi_lag1=_align(Pi_lag1),
        collapse=_align(collapse.astype(float)),
        components={k: _align(v) for k, v in components.items()},
    )
