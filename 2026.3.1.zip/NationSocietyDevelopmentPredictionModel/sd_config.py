"""
StateDynamics v0.3 — Double-Helix Six-Factor (theory-first) implementation
==========================================================================

可配置项：国家、年份、指标代码、权重与核参数。
"""

# ------------------ Countries & Horizon ------------------
COUNTRIES = ["CHN", "AUS", "USA", "SGP", "HKG"]
YEAR_START = 2000
YEAR_END = 2024  # WDI/WGI 常见的最近完整年

# ------------------ Indicator Codes ------------------
# 这些代码均来自世界银行 WDI / WGI（由 sd_data.py 的注释页核对）。
INDICATORS = {
    # 不平等 / 财富差（ΔW 驱动）
    "GINI": "SI.POV.GINI",

    # 安全 / 生存威胁（ΔS 驱动）
    "HOMICIDE_P5": "VC.IHR.PSRC.P5",  # 故意杀人率（每10万人）

    # 叙事带宽与连通性（B(t) 观测）
    "INTERNET_USERS": "IT.NET.USER.ZS",  # % of population
    "MOBILE_SUBS": "IT.CEL.SETS.P2",     # per 100 people

    # 治理（WGI：η_E、ΔC、B(t)、μ_k 的组成）
    "VA_EST": "VA.EST",  # Voice & Accountability
    "GE_EST": "GE.EST",  # Government Effectiveness
    "RQ_EST": "RQ.EST",  # Regulatory Quality
    "RL_EST": "RL.EST",  # Rule of Law
    "CC_EST": "CC.EST",  # Control of Corruption
    "PV_EST": "PV.EST",  # Political Stability & Absence of Violence

    # 资本与税制
    "GFCF_PCT_GDP": "NE.GDI.FTOT.ZS",    # 资本形成（%GDP）→ ρṀ
    "FDI_PCT_GDP": "BX.KLT.DINV.WD.GD.ZS",
    "GDP_GROWTH": "NY.GDP.MKTP.KD.ZG",   # 冲击检测之一
    "TAX_PCT_GDP": "GC.TAX.TOTL.GD.ZS",  # ψ_tax

    # 技能/科研
    "RND_PCT_GDP": "GB.XPD.RSDV.GD.ZS",
    "RND_RESEARCHERS_PM": "SP.POP.SCIE.RD.P6",
    "TERTIARY_ENROLL": "SE.TER.ENRR",

    # PITF baseline proxies (Goldstone et al. 2010, AJPS)
    "INFANT_MORT": "SP.DYN.IMRT.IN",        # under-5 mortality per 1,000 live births
    "GINI_DISPOSABLE": "SI.DST.10TH.10",    # income share top 10% (backup for GINI)
}

# ------------------ Theoretical Weights ------------------
# Tension: T = α ΔW + β ΔC + γ ΔS  (T_adj = T * (1 - η_E))
WEIGHTS = {"alpha_W": 1.0, "beta_C": 1.0, "gamma_S": 1.0}

# Latent narrative bandwidth B(t) = σ( wI z(INET) + wM z(MOBILE) )
# wV (VA.EST) removed — FIX B: VA.EST already captured in ΔC, using it here
# would cause multicollinearity. Weights renormalized: wI=0.7, wM=0.3.
B_WEIGHTS = {"wI": 0.7, "wM": 0.3}

# Elite concession η_E：正向治理改善的滚动均值（缩放 0..1）
ETA_E = {"window_years": 3, "w_ge": 0.3, "w_rq": 0.3, "w_rl": 0.2, "w_cc": 0.2}

# Cross-jurisdiction friction μ_k：FDI 低+监管弱 ⇒ 摩擦高（缩放 0..1）
MU_K = {"w_neg_fdi": 0.6, "w_neg_rq": 0.4}

# Hawkes-like shock kernel F(t) 参数
HAWKES = {"lambda": 0.45, "z_threshold": 2.0, "max_events_per_year": 3}

# Individual opportunity Π_ind 参数（Π = σ_skill − μ_k + ρṀ − ψ_tax）
PI_INDIVIDUAL = {"psi_tax_scale": 1.0, "rho_from": "GFCF_PCT_GDP"}

# ------------------ Collapse Thresholds (FIX C) ------------------
# R_eff in [0, 1] (explicitly clipped); S_eff is panel_zscore-scaled.
R_MIN = 0.20
S_MIN = 0.30

# ------------------ ML Settings ------------------
CV_FOLDS         = 5
XGB_N_ESTIMATORS = 500
XGB_MAX_DEPTH    = 4
XGB_LR           = 0.05
RF_N_ESTIMATORS  = 300
