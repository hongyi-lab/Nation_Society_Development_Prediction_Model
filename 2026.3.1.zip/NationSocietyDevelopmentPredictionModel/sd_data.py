"""
sd_data.py — Robust World Bank fetcher with retry/backoff + disk cache + progress
---------------------------------------------------------------------------------
改动要点：
- Session 级 Retry（429/5xx + 连接/读取）+ 指数退避 + 可调超时
- 友好 User-Agent（部分数据站点会因默认 UA 拒绝或限流）
- 每次调用之间 sleep（可调），降低被限流概率
- 磁盘缓存：cache/wb_{ISO}_{IND}.csv（API 失败时自动回退）
- 详细进度打印：告诉你正在拉哪个国家的哪个指标
"""
from __future__ import annotations
import os, time
import requests
import pandas as pd
from typing import List, Dict, Optional
from dataclasses import dataclass

# -------------------- Tunables via env vars --------------------
DEFAULT_TIMEOUT = float(os.getenv("WB_API_TIMEOUT", "45"))         # 单次请求超时（秒）
DEFAULT_RETRIES = int(os.getenv("WB_API_RETRIES", "3"))            # 自动重试次数
BACKOFF_FACTOR   = float(os.getenv("WB_API_BACKOFF", "1.5"))       # 退避因子
SLEEP_BETWEEN    = float(os.getenv("WB_SLEEP_BETWEEN", "0.40"))    # 每次请求之间暂停（秒）
CACHE_DIR        = os.getenv("WB_CACHE_DIR", "cache")              # 磁盘缓存目录
VERBOSE_DEFAULT  = (os.getenv("WB_VERBOSE", "1") == "1")

os.makedirs(CACHE_DIR, exist_ok=True)

WB_URL_TPL = (
    "https://api.worldbank.org/v2/country/{country}/indicator/{indicator}?format=json&per_page=20000"
)

def _make_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": "StateDynamics-v0.3 (+https://example.org) requests/2.x"
    })
    # 配置 Retry（若环境缺少 urllib3.Retry，则静默跳过，改用手动循环）
    try:
        from urllib3.util.retry import Retry
        from requests.adapters import HTTPAdapter
        retry = Retry(
            total=DEFAULT_RETRIES,
            connect=DEFAULT_RETRIES,
            read=DEFAULT_RETRIES,
            status=DEFAULT_RETRIES,
            allowed_methods=["GET"],
            backoff_factor=BACKOFF_FACTOR,
            status_forcelist=[429, 500, 502, 503, 504],
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
    except Exception:
        pass
    return s

SESSION = _make_session()

def _cache_path(iso: str, indicator: str) -> str:
    safe = indicator.replace("/", "_")
    return os.path.join(CACHE_DIR, f"wb_{iso}_{safe}.csv")

def _try_load_cache(iso: str, indicator: str, verbose: bool) -> Optional[pd.DataFrame]:
    path = _cache_path(iso, indicator)
    if os.path.exists(path):
        if verbose: print(f"[WB][cache] {iso} {indicator} -> {path}")
        try:
            df = pd.read_csv(path)
            # 旧缓存可能存了 2 字母代码（如 "AU"），统一覆盖为传入的 ISO3
            if "country" in df.columns:
                df["country"] = iso
            return df
        except Exception as e:
            if verbose: print(f"[WB][cache] read failed: {e}")
    return None

def _save_cache(df: pd.DataFrame, iso: str, indicator: str, verbose: bool) -> None:
    try:
        path = _cache_path(iso, indicator)
        df.to_csv(path, index=False)
        if verbose: print(f"[WB][cache] saved -> {path}")
    except Exception as e:
        if verbose: print(f"[WB][cache] save failed: {e}")

def _wb_pull(country: str, indicator: str, start: Optional[int], end: Optional[int],
             verbose: bool = VERBOSE_DEFAULT) -> pd.DataFrame:
    url = WB_URL_TPL.format(country=country, indicator=indicator)
    if start or end:
        s = start if start else ""
        e = end if end else ""
        url += f"&date={s}:{e}"

    # 手动重试（即使上面的 Retry 生效，这里也能兜底）
    attempts = DEFAULT_RETRIES + 1
    last_err = None
    for k in range(1, attempts + 1):
        if verbose:
            print(f"[WB][{country}] {indicator} try {k}/{attempts} ...", flush=True)
        try:
            resp = SESSION.get(url, timeout=DEFAULT_TIMEOUT)
            resp.raise_for_status()
            payload = resp.json()
            if not isinstance(payload, list) or len(payload) < 2 or not isinstance(payload[1], list):
                # WB 偶尔只返回 meta；尝试 cache 回退
                cached = _try_load_cache(country, indicator, verbose)
                if cached is not None:
                    return cached
                if verbose:
                    print(f"[WB][{country}] {indicator} empty payload structure, returning empty frame.")
                return pd.DataFrame(columns=["country", "year", indicator])

            rows = []
            for d in payload[1]:
                y = d.get("date")
                v = d.get("value")
                if y is None:
                    continue
                try:
                    y = int(y)
                except Exception:
                    continue
                rows.append({
                    "country": country,   # 用传入的 ISO3 代码，而非 API 返回的 2 字母 id
                    "year": y,
                    indicator: float(v) if v is not None else pd.NA
                })
            df = pd.DataFrame(rows).dropna(subset=[indicator])
            if not df.empty:
                _save_cache(df, country, indicator, verbose)
            time.sleep(SLEEP_BETWEEN)  # 轻度限速
            return df

        except requests.exceptions.RequestException as e:
            last_err = e
            if verbose:
                print(f"[WB][{country}] {indicator} warn: {e.__class__.__name__}: {e}")
            # 简单指数退避
            sleep_s = min(10.0, (BACKOFF_FACTOR ** (k - 1)) * SLEEP_BETWEEN)
            time.sleep(sleep_s)
            continue

    # 全部尝试失败 → 读缓存；无缓存则给空表但不崩
    cached = _try_load_cache(country, indicator, verbose)
    if cached is not None:
        return cached

    if verbose:
        print(f"[WB][{country}] {indicator} FAILED after retries; returning empty frame.")
    return pd.DataFrame(columns=["country", "year", indicator])

@dataclass
class WBFetchPlan:
    countries: List[str]
    indicators: List[str]
    start: Optional[int] = None
    end: Optional[int] = None

def fetch_plan(plan: WBFetchPlan, verbose: bool = VERBOSE_DEFAULT) -> pd.DataFrame:
    """
    多国多指标抓取，安全合并版本：
    - 先收集所有小表
    - 用 (country, year) 作为索引进行逐列合并：
      * 如果某个指标列已存在：按键对齐后用 combine_first 补齐（避免 _x/_y）
      * 如果不存在：直接外连接新增该列
    - 任何单项失败不会中断全局
    """
    # 1) 拉取
    frames: List[pd.DataFrame] = []
    total = len(plan.countries) * len(plan.indicators)
    step = 0
    for iso in plan.countries:
        for ind in plan.indicators:
            step += 1
            if verbose:
                print(f"[WB][{step}/{total}] fetching {iso} · {ind}")
            try:
                df = _wb_pull(iso, ind, plan.start, plan.end, verbose=verbose)
                frames.append(df)
            except Exception as e:
                if verbose:
                    print(f"[WB][{iso}] {ind} HARD FAIL: {e} — appended empty for continuity.")
                frames.append(pd.DataFrame(columns=["country", "year", ind]))

    # 2) 安全合并（无后缀策略）
    # 起一个只有键的空骨架
    merged = pd.DataFrame(columns=["country", "year"]).astype({"country": "object", "year": "float"})
    merged = merged.set_index(["country", "year"])

    for r in frames:
        if r is None or r.empty:
            continue
        cols = [c for c in r.columns if c not in ("country", "year")]
        if not cols:
            # 只有键，没有指标列
            continue
        ind_col = cols[0]  # 每张小表只有一个指标列
        df_i = r.set_index(["country", "year"])[[ind_col]]

        # 对齐键的并集
        merged = merged.join(pd.DataFrame(index=df_i.index), how="outer")

        if ind_col in merged.columns:
            # 已经有这个指标列：用 combine_first 补齐空缺
            merged[ind_col] = merged[ind_col].combine_first(df_i[ind_col])
        else:
            # 新指标列：外连接加入
            merged = merged.join(df_i, how="left")

    merged = merged.reset_index()

    # 排序与返回
    if "year" in merged.columns:
        # year 可能是 float（由空表造成），尽量转成 Int64 方便后续
        try:
            merged["year"] = merged["year"].astype("Int64")
        except Exception:
            pass
    merged = merged.sort_values(["country", "year"]).reset_index(drop=True)
    return merged


def to_country_dict(df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    out = {}
    for iso, g in df.groupby("country"):
        out[iso] = g.drop(columns=["country"]).set_index("year").sort_index()
    return out
