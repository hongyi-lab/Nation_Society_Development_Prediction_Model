"""
sd_coupling_check.py — Empirical validation of inter-factor coupling
---------------------------------------------------------------------
Tests which of the six StateDynamics factors Granger-cause each other,
providing an empirical basis for the coupling terms added in sd_model.py.

This answers: are the theoretical coupling terms (tension_narrative,
skill_net_friction) justified by the data, or are they purely theoretical?

Reference:
  Dumitrescu & Hurlin (2012): Testing for Granger non-causality in
  heterogeneous panels. Economic Modelling 29(4):1450–1460.
  Granger (1969): Investigating causal relations by econometric models.
  Econometrica 37(3):424–438.

Usage (standalone):
    python sd_coupling_check.py
    # requires country_outputs from a prior sd_run.py run (or pass dict directly)
"""
from __future__ import annotations

import os
import warnings
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")  # headless — no display required
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
import pandas as pd

from statsmodels.tsa.stattools import grangercausalitytests

from sd_model import SixFactorOutputs

# Six factors to evaluate pairwise
FACTORS: List[str] = ["T_adj", "S_eff", "F_t", "Pi_ind", "mu_k", "sigma_skill"]

# Minimum years of non-NaN data required per country to run the test
MIN_OBS = 10
# Granger test maximum lag
MAX_LAG = 2
# Significance threshold for p-value
ALPHA = 0.05
# Fraction threshold to call a coupling "empirically supported"
SUPPORT_THRESHOLD = 0.30


def _extract_factor_df(out: SixFactorOutputs) -> pd.DataFrame:
    """
    Build a per-country DataFrame of the six primary factors
    from a SixFactorOutputs object.
    """
    return pd.DataFrame({
        "T_adj":       out.T_adj,
        "S_eff":       out.S_eff,
        "F_t":         out.F_t,
        "Pi_ind":      out.Pi_ind,
        "mu_k":        out.mu_k,
        "sigma_skill": out.sigma_skill,
    })


def _granger_min_pval(data: pd.DataFrame, cause: str, effect: str) -> float | None:
    """
    Run Granger causality test: does `cause` Granger-cause `effect`?

    statsmodels convention: grangercausalitytests(x, maxlag) tests whether
    the SECOND column Granger-causes the FIRST column.
    → We pass data[[effect, cause]] to test "cause → effect".

    Returns the minimum p-value across lags (F-test), or None on failure.
    """
    xy = data[[effect, cause]].dropna()
    if len(xy) < MIN_OBS:
        return None
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = grangercausalitytests(xy, maxlag=MAX_LAG, verbose=False)
        # Extract min p-value across all lags (F-test: ssr_ftest)
        pvals = [result[lag][0]["ssr_ftest"][1] for lag in result]
        return float(min(pvals))
    except Exception:
        return None


def run_granger_matrix(
    country_outputs: Dict[str, SixFactorOutputs],
    out_dir: str = "out",
) -> pd.DataFrame:
    """
    Compute a 6×6 pairwise Granger causality significance matrix.

    For each ordered pair (cause → effect) and each eligible country:
      - Run grangercausalitytests with maxlag=2
      - Record whether min p-value < 0.05

    Aggregate: sig_fraction[effect][cause] = count(p < α) / n_eligible_countries

    This tells you: "In what fraction of countries does factor X appear to
    Granger-cause factor Y?" Pairs with sig_fraction > 0.30 are considered
    empirically supported couplings.

    Parameters
    ----------
    country_outputs : dict  {iso3: SixFactorOutputs}
    out_dir         : directory for output plot

    Returns
    -------
    pd.DataFrame  (6×6, index=effect, columns=cause, values=sig_fraction)
    """
    os.makedirs(out_dir, exist_ok=True)

    # sig_count[effect][cause] = n_countries where cause Granger-causes effect
    sig_count = pd.DataFrame(0, index=FACTORS, columns=FACTORS, dtype=float)
    n_eligible = 0

    for iso, out in country_outputs.items():
        df = _extract_factor_df(out).dropna()
        if len(df) < MIN_OBS:
            print(f"[granger] {iso}: only {len(df)} obs — skipped (need ≥{MIN_OBS})")
            continue
        n_eligible += 1
        print(f"[granger] {iso}: {len(df)} obs — running {len(FACTORS)**2 - len(FACTORS)} pairs")

        for cause in FACTORS:
            for effect in FACTORS:
                if cause == effect:
                    continue
                pval = _granger_min_pval(df, cause=cause, effect=effect)
                if pval is not None and pval < ALPHA:
                    sig_count.loc[effect, cause] += 1

    if n_eligible == 0:
        print("[granger] No eligible countries. Returning empty matrix.")
        return pd.DataFrame(index=FACTORS, columns=FACTORS)

    sig_fraction = sig_count / n_eligible

    # ------------------------------------------------------------------
    # Print supported couplings
    # ------------------------------------------------------------------
    print(f"\n[granger] Eligible countries: {n_eligible} | "
          f"Significance threshold: p < {ALPHA} | "
          f"Support threshold: sig_fraction > {SUPPORT_THRESHOLD}")
    print(f"\nEmpirical coupling pairs (sig_fraction > {SUPPORT_THRESHOLD}):")
    print(f"  {'Cause':<14} → {'Effect':<14}  sig_fraction")
    print(f"  {'-'*46}")
    found_any = False
    for cause in FACTORS:
        for effect in FACTORS:
            if cause == effect:
                continue
            frac = sig_fraction.loc[effect, cause]
            if frac > SUPPORT_THRESHOLD:
                print(f"  {cause:<14} → {effect:<14}  {frac:.2f}")
                found_any = True
    if not found_any:
        print("  (none exceed the threshold — all coupling terms remain theoretical)")

    # ------------------------------------------------------------------
    # Heatmap
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 6))
    mat = sig_fraction.values.astype(float)

    cmap = mcolors.LinearSegmentedColormap.from_list(
        "granger", ["#f7fbff", "#2171b5", "#08306b"]
    )
    im = ax.imshow(mat, vmin=0.0, vmax=1.0, cmap=cmap, aspect="auto")

    ax.set_xticks(range(len(FACTORS)))
    ax.set_yticks(range(len(FACTORS)))
    ax.set_xticklabels(FACTORS, rotation=30, ha="right", fontsize=9)
    ax.set_yticklabels(FACTORS, fontsize=9)
    ax.set_xlabel("Cause  →", fontsize=10)
    ax.set_ylabel("→  Effect", fontsize=10)
    ax.set_title(
        f"Granger Causality: fraction of countries with p < {ALPHA}\n"
        f"(n={n_eligible} countries, maxlag={MAX_LAG})",
        fontsize=11,
    )

    # Annotate cells
    for r in range(len(FACTORS)):
        for c in range(len(FACTORS)):
            val = mat[r, c]
            txt = "—" if r == c else f"{val:.2f}"
            color = "white" if val > 0.6 else "black"
            ax.text(c, r, txt, ha="center", va="center", fontsize=8, color=color)

    # Mark supported pairs with a border
    for r, effect in enumerate(FACTORS):
        for c, cause in enumerate(FACTORS):
            if cause == effect:
                continue
            if sig_fraction.loc[effect, cause] > SUPPORT_THRESHOLD:
                rect = plt.Rectangle(
                    (c - 0.48, r - 0.48), 0.96, 0.96,
                    linewidth=2, edgecolor="#e6550d", facecolor="none",
                )
                ax.add_patch(rect)

    plt.colorbar(im, ax=ax, label="Sig. fraction across countries")
    plt.tight_layout()

    out_path = os.path.join(out_dir, "granger_coupling_matrix.png")
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    print(f"\n[granger] Heatmap saved → {out_path}")

    return sig_fraction


# ---------------------------------------------------------------------------
# Standalone entry point for testing
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    sys.path.insert(0, ".")

    # Try to reconstruct country_outputs from cached WB data
    try:
        from sd_config import (
            COUNTRIES, YEAR_START, YEAR_END, INDICATORS,
            WEIGHTS, B_WEIGHTS, ETA_E, MU_K, HAWKES, PI_INDIVIDUAL,
            R_MIN, S_MIN,
        )
        from sd_data import WBFetchPlan, fetch_plan, to_country_dict
        from sd_model import compute_country_outputs

        print("[granger] Building country outputs from cache ...")
        plan = WBFetchPlan(
            countries=COUNTRIES,
            indicators=list(INDICATORS.values()),
            start=YEAR_START,
            end=YEAR_END,
        )
        df = fetch_plan(plan, verbose=False)
        country_dfs = to_country_dict(df)
        country_outputs: Dict[str, SixFactorOutputs] = {}
        for iso in COUNTRIES:
            if iso not in country_dfs:
                continue
            try:
                country_outputs[iso] = compute_country_outputs(
                    country_dfs[iso], WEIGHTS, B_WEIGHTS, ETA_E, MU_K,
                    HAWKES, PI_INDIVIDUAL, R_min=R_MIN, S_min=S_MIN,
                )
            except Exception as e:
                print(f"[granger] {iso} failed: {e}")

        result = run_granger_matrix(country_outputs)
        print("\nSig-fraction matrix:\n", result.round(2))

    except Exception as e:
        print(f"[granger] Standalone run failed: {e}")
        raise
