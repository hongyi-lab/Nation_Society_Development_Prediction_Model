"""
sd_labels.py — Target variable construction for instability prediction
-----------------------------------------------------------------------
Provides three functions:
  load_pitf_labels()            - Load PITF event data or fallback to WGI proxy.
  add_years_since_event()       - Compute temporal distance to last event.
  merge_labels_with_features()  - Join labels onto feature DataFrame.

Academic basis:
  - PITF data: Political Instability Task Force (2019).
    http://www.pitf.us.gov/ (restricted access)
  - Goldstone et al. (2010, AJPS): Three-variable PITF baseline model.
  - Hegre & Sambanis (2006): Sensitivity analysis of civil war onset models.
"""
from __future__ import annotations

import os
import warnings
from typing import Optional

import numpy as np
import pandas as pd

CACHE_DIR = os.getenv("WB_CACHE_DIR", "cache")


# ---------------------------------------------------------------------------
# 1. Load / construct instability onset labels
# ---------------------------------------------------------------------------

def load_pitf_labels(filepath: str | None = None) -> pd.DataFrame:
    """
    Load binary instability onset labels (0/1 per country-year).

    Parameters
    ----------
    filepath : str or None
        Path to a PITF-format CSV file.
        Expected columns:
          country (ISO3 string), year (int),
          ethnic_war (0/1), rev_war (0/1), adverse_regime (0/1), genocide (0/1)
        instability_onset = row-wise max of those four binary columns.

        If None: fallback mode is activated.

    Fallback mode
    -------------
    When PITF data is unavailable, uses PV.EST (WGI Political Stability and
    Absence of Violence) from the local disk cache populated by sd_data.py.

    instability_onset = 1  if  PV.EST < 25th percentile of that country's
                                own historical PV.EST distribution, else 0.

    **Approximation warning**: PV.EST measures composite expert perceptions of
    political stability, NOT actual conflict event coding. The 25th-percentile
    threshold flags years of relative deterioration within a country, not
    absolute instability. Avoid using fallback results for publication.
    PITF provides actual coding of ethnic war, revolution, adverse regime
    change, and genocide/politicide onset — qualitatively different from
    a WGI proxy.

    Returns
    -------
    pd.DataFrame
        Columns: country (str ISO3), year (int), instability_onset (int 0/1).
    """
    if filepath is not None:
        df = pd.read_csv(filepath)
        required = {"country", "year", "ethnic_war", "rev_war", "adverse_regime", "genocide"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(f"PITF CSV missing expected columns: {missing}")

        df["country"] = df["country"].astype(str).str.upper().str.strip()
        df["year"] = df["year"].astype(int)

        event_cols = ["ethnic_war", "rev_war", "adverse_regime", "genocide"]
        df["instability_onset"] = df[event_cols].fillna(0).max(axis=1).astype(int)

        return df[["country", "year", "instability_onset"]].reset_index(drop=True)

    # ------------------------------------------------------------------
    # Fallback: PV.EST proxy from World Bank cache
    # ------------------------------------------------------------------
    warnings.warn(
        "\n[sd_labels] WARNING: PITF data unavailable (filepath=None).\n"
        "Falling back to PV.EST (WGI Political Stability) proxy.\n"
        "instability_onset = 1 if PV.EST < country's own 25th-percentile.\n"
        "This is a rough approximation — interpret downstream results with caution.",
        UserWarning,
        stacklevel=2,
    )

    if not os.path.isdir(CACHE_DIR):
        print(f"[sd_labels] Cache directory '{CACHE_DIR}' not found. "
              "Return empty labels. Run sd_run.py first to populate cache.")
        return pd.DataFrame(columns=["country", "year", "instability_onset"])

    pv_frames: list[pd.DataFrame] = []
    for fname in os.listdir(CACHE_DIR):
        if "PV.EST" in fname and fname.endswith(".csv"):
            fpath = os.path.join(CACHE_DIR, fname)
            try:
                pv_frames.append(pd.read_csv(fpath))
            except Exception as exc:
                print(f"[sd_labels] Could not read {fname}: {exc}")

    if not pv_frames:
        print(
            "[sd_labels] No PV.EST cache files found in cache/. "
            "Run sd_run.py first to fetch data, then retry."
        )
        return pd.DataFrame(columns=["country", "year", "instability_onset"])

    pv = pd.concat(pv_frames, ignore_index=True)

    # Identify the PV.EST value column (everything that is not 'country'/'year')
    val_cols = [c for c in pv.columns if c not in ("country", "year")]
    if not val_cols:
        print("[sd_labels] PV.EST cache files have no value column.")
        return pd.DataFrame(columns=["country", "year", "instability_onset"])
    pv_col = val_cols[0]

    pv["year"] = pv["year"].astype(int)
    pv["country"] = pv["country"].astype(str).str.upper().str.strip()
    pv = pv.dropna(subset=[pv_col])

    def _flag_by_quantile(group: pd.DataFrame) -> pd.DataFrame:
        p25 = group[pv_col].quantile(0.25)
        group = group.copy()
        group["instability_onset"] = (group[pv_col] < p25).astype(int)
        return group[["country", "year", "instability_onset"]]

    result = pv.groupby("country", group_keys=False).apply(_flag_by_quantile)
    return result.reset_index(drop=True)


# ---------------------------------------------------------------------------
# 2. Temporal feature: years since last instability event
# ---------------------------------------------------------------------------

def add_years_since_event(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the number of years elapsed since the previous instability onset.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: country (str), year (int), instability_onset (int 0/1).

    Returns
    -------
    pd.DataFrame
        Input df with an added column 'years_since_last_event'.
        Value is 0 for a country's earliest observation or if no prior
        event exists in the data window.

    Notes
    -----
    'Years since last event' is one of the three predictors in the Goldstone
    et al. (2010, AJPS) PITF baseline model. Prior conflict is strongly
    predictive of future onset due to institutional weakening, unresolved
    grievances, and the 'conflict trap' mechanism (Collier 2003).
    Including this variable allows the downstream classifier to replicate
    and improve upon the PITF 3-variable benchmark.
    """
    df = df.copy().sort_values(["country", "year"]).reset_index(drop=True)
    df["years_since_last_event"] = 0

    for country, grp_idx in df.groupby("country").groups.items():
        grp = df.loc[grp_idx].sort_values("year")
        last_event_year: Optional[int] = None
        for idx, row in grp.iterrows():
            if last_event_year is None:
                df.at[idx, "years_since_last_event"] = 0
            else:
                df.at[idx, "years_since_last_event"] = int(row["year"]) - last_event_year
            if int(row["instability_onset"]) == 1:
                last_event_year = int(row["year"])

    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# 3. Merge labels with model features
# ---------------------------------------------------------------------------

def merge_labels_with_features(
    features_df: pd.DataFrame,
    labels_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Left-join model features with instability labels on (country, year).

    Parameters
    ----------
    features_df : pd.DataFrame
        Panel data with at minimum columns: country (str ISO3), year (int).
        Typically the long-format output from sd_run.py (metrics_long.csv).
    labels_df : pd.DataFrame
        Output of load_pitf_labels() optionally passed through
        add_years_since_event(). Must contain: country, year, instability_onset.

    Returns
    -------
    pd.DataFrame
        Merged frame. Rows where instability_onset is NaN after the join
        (i.e., country-years outside the labels coverage window) are dropped.
        All remaining rows have a valid integer instability_onset.

    Notes
    -----
    Prints a class balance summary. A 1:50+ positive-to-negative ratio is
    typical for conflict onset data (Hegre & Sambanis 2006). This severe
    imbalance is why downstream classifiers use class_weight='balanced'
    rather than default settings, and why AUPRC is preferred over AUC-ROC
    as the primary evaluation metric (Davis & Goadrich 2006, ICML).
    """
    features_df = features_df.copy()
    labels_df = labels_df.copy()

    # Normalise join keys
    features_df["country"] = features_df["country"].astype(str).str.upper().str.strip()
    labels_df["country"] = labels_df["country"].astype(str).str.upper().str.strip()
    features_df["year"] = features_df["year"].astype(int)
    labels_df["year"] = labels_df["year"].astype(int)

    merged = features_df.merge(labels_df, on=["country", "year"], how="left")
    merged = merged.dropna(subset=["instability_onset"])
    merged["instability_onset"] = merged["instability_onset"].astype(int)

    total = len(merged)
    pos = int(merged["instability_onset"].sum())
    neg = total - pos
    ratio_str = f"1:{neg // pos}" if pos > 0 else "∞ (no positive cases)"
    print(
        f"[sd_labels] Merged dataset: {total} rows | "
        f"Positive (instability=1) = {pos} | "
        f"Negative (instability=0) = {neg} | "
        f"Ratio pos:neg ≈ {ratio_str}"
    )

    return merged.reset_index(drop=True)
